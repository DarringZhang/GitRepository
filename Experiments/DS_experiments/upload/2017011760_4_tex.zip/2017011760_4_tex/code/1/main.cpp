#include "UnDirectedGraph.h"
int main() {
    UnDirectedGraph graph;
    graph.createAdjGraph();
    graph.display();
    return 0;
}

