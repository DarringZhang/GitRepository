#include "DirectedGraph.h"
int main() {
    DirectedGraph graph;
    graph.createAdjGraph();
    graph.display();
    return 0;
}